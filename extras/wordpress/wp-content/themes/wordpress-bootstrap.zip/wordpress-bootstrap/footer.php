
      <footer>
        2013 &copy; 
        <a href="http://www.social-stream.dit.upm.es">
          Social Stream
        </a>
        -
        <a href="http://www.dit.upm.es/">
          DIT - UPM telecommunication
        </a>
      </footer> <!-- end footer -->
    
    </div> <!-- end #container -->
        
    <!--[if lt IE 7 ]>
        <script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
        <script>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
    <![endif]-->
    
    <?php wp_footer(); // js scripts are inserted using this function ?>

  </body>

</html>